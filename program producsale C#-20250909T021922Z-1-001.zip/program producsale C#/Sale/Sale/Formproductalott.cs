﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Microsoft.VisualBasic;
using System.IO;

namespace Sale
{
    public partial class Formproductalott : Form
    {
        public Formproductalott()
        {
            InitializeComponent();
        }

        private void Formproductalott_Load(object sender, EventArgs e)
        {
            Loadproduct();
        }
        private void Loadproduct()
        {
            try
            {
                DataConn.sqL = "SELECT * FROM   tbproductalot";// WHERE Build_groupuse = '" + TxtGroupB.Text + "' AND Build_departuse = '" + TxtDepartB.Text + "' AND Build_sectionuse = '" + TxtSectionB.Text + "' And Build_UseNow=1";  
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.dr = DataConn.cmd.ExecuteReader();

                dataGridView1.Rows.Clear();
                {
                    while (DataConn.dr.Read() == true)
                    {
                        dataGridView1.Rows.Add((dataGridView1.RowCount + 1), DataConn.dr[1], DataConn.dr[2], DataConn.dr[3], DataConn.dr[4], DataConn.dr[5], DataConn.dr[6], DataConn.dr[7], DataConn.dr[8], DataConn.dr[9], DataConn.dr[10], DataConn.dr[11], DataConn.dr[12]);
                    }
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message);
            }
            finally
            {
                DataConn.cmd.Dispose();
                DataConn.conn.Close();
            }
        }

        private void txtproname_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtpropass_TextChanged(object sender, EventArgs e)
        {
            ImageGet1();
        }
        private void ImageGet1()
        {
            //Dataconn.sqL = "SELECT * FROM tb_Beverage WHERE Beverage_Id = '" + (dataGridView1.CurrentRow.Cells[0].Value.ToString()) + "'";
            DataConn.sqL = "SELECT * FROM tbproname WHERE propass = '" + txtpropass.Text + "'";
            DataConn.ConnDB();
            DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
            DataConn.dr = DataConn.cmd.ExecuteReader();
            while (DataConn.dr.Read())
            {
                byte[] imgg = (byte[])(DataConn.dr["proimage"]);
                if (imgg == null)
                {
                    propicture.Image = null;
                }
                else
                {
                    MemoryStream mstream = new MemoryStream(imgg);
                    propicture.Image = System.Drawing.Image.FromStream(mstream);

                    txtproname.Text = (DataConn.dr.GetString("proname"));
                    txtprotype.Text = (DataConn.dr.GetString("protype"));
                    txtprogroup.Text = (DataConn.dr.GetString("progroup"));
                }
            }
            DataConn.conn.Close();
            }
        private void Loadprototal()
        {

            {
                DataConn.sqL = "SELECT * FROM tbproductalot Where propass = '" + txtpropass.Text + "'";
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.dr = DataConn.cmd.ExecuteReader();
                if (DataConn.dr.Read() == true)
                {
                    txtinstock.Text = (DataConn.dr.GetString("prototal"));
                    // txtprotype.Text = (DataConn.dr.GetString("protype"));
                    // txtprogroup.Text = (DataConn.dr.GetString("progroup"));
                }

            }
        }

        private void txtproincome_TextChanged(object sender, EventArgs e)
        {
            Double x, y, z;
            x = Convert.ToDouble(txtproincome.Text);
            y = Convert.ToDouble(txtinstock.Text);

            z = x + y;
            txttotal.Text = z.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddNewproduct();
            Loadproduct();
            propicture.Image = Image.FromFile(@"..\..\Resources\NoImage.jpeg");
        }
        private void AddNewproduct()
        {
            try
            {


                DataConn.sqL = "SELECT * FROM tbproductalot WHERE billno = '" + txtbillno.Text + "' and proname = '" + txtproname.Text + "'";
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.dr = DataConn.cmd.ExecuteReader();
                if (DataConn.dr.Read() == true)
                {
                    MessageBox.Show("ຂໍ້ມູນນີ້ມີແລ້ວກະລູນາປ່ຽນໃໝ່");
                    txtbillno.Text = "";
                    txtbillno.Focus();
                }

                DataConn.sqL = "SELECT * FROM tbproductalot WHERE proname = '" + txtproname.Text + "'";
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.dr = DataConn.cmd.ExecuteReader();
                if (DataConn.dr.Read() == true)
                {
                    DataConn.sqL = "UPDATE tbproductalot SET  proincome = '" + txtproincome.Text + "', proinstock = '" + txtinstock.Text + "', prototal = '" + txttotal.Text + "' WHERE  propass ='" + txtpropass.Text + "'";
                    DataConn.ConnDB();
                    DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                    DataConn.cmd.ExecuteNonQuery();
                }
                else
                {

                    DataConn.sqL = "INSERT INTO tbproductalot(billno, propass, proname, progroup, protype, proincome, proinstock, prototal, probuy, prosale, prodate, proless) VALUES('" + txtbillno.Text + "', " +
                        "'" + txtpropass.Text + "', " +
                        "'" + txtproname.Text + "', " +
                        "'" + txtprogroup.Text + "', " +
                        "'" + txtprotype.Text + "', " +
                        "'" + txtproincome.Text + "', " +
                        "'" + txtinstock.Text + "', " +
                        "'" + txttotal.Text + "', " +
                        "'" + txtbuy.Text + "', " +
                        "'" + txtsale.Text + "', " +
                        "'" + txtdate.Text + "', " +
                        "'" + txtless.Text + "')";

                    DataConn.ConnDB();
                    DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                    DataConn.cmd.ExecuteNonQuery();
                    Interaction.MsgBox("New category successfully added.", MsgBoxStyle.Information, "Add New User");

                    txtbillno.Text = "";
                    txtpropass.Text = "";
                    txtproname.Text = "";
                    txtprogroup.Text = "";
                    txtprotype.Text = "";
                    txtproincome.Text = "0";
                    txtinstock.Text = "0";
                    txttotal.Text = "0";
                    txtbuy.Text = "0";
                    txtsale.Text = "0";
                    txtless.Text = "0";





                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                DataConn.cmd.Dispose();
                DataConn.conn.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Updateproduct();
            Loadproduct();
        }
        private void Updateproduct()
        {

            System.IO.MemoryStream mstream = new System.IO.MemoryStream();
            propicture.Image.Save(mstream, System.Drawing.Imaging.ImageFormat.Jpeg);
            byte[] arrImage = mstream.GetBuffer();
            //FileSize = mstream.Length;
            mstream.Close();
            try
            {
                DataConn.sqL = "UPDATE tbproductalot SET  proincome = '" + txtproincome.Text + "', proinstock = '" + txtinstock.Text + "', prototal = '" + txttotal.Text + "' WHERE  propass ='" + txtpropass.Text + "'";
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                // DataConn.cmd.Parameters.Add(new MySqlParameter("@proimage", arrImage));
                DataConn.cmd.ExecuteNonQuery();
                Interaction.MsgBox("Category successfully updated.", MsgBoxStyle.Information, "Update Category");

                txtbillno.Text = "";
                txtpropass.Text = "";
                txtproname.Text = "";
                txtprogroup.Text = "";
                txtprotype.Text = "";
                txtproincome.Text = "0";
                txtinstock.Text = "0";
                txttotal.Text = "0";
                txtbuy.Text = "0";
                txtsale.Text = "0";
                txtless.Text = "0";
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                DataConn.cmd.Dispose();
                DataConn.conn.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Deleteproduct();
            Loadproduct();
        }
          private void Deleteproduct()
        {
            if (MessageBox.Show("Are You sure you want to delete ", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                == DialogResult.Yes)
            {
                DataConn.sqL = "DELETE from tbproductalot  WHERE propass ='" + txtpropass.Text + "' and proincome='" + txtproincome.Text + "'"; //User_Name= '" + Txt_Name.Text + "', User_Pass = '" + Txt_Pass.Text + "' , User_State = '" + Cmb_State.Text + "' WHERE User_Name = '" + Txt_Name.Text + "'";
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.cmd.ExecuteNonQuery();
                Interaction.MsgBox("Category successfully Delete.", MsgBoxStyle.Information, "Delete Category");
                txtbillno.Text = "";
                txtpropass.Text = "";
                txtproname.Text = "";
                txtprogroup.Text = "";
                txtprotype.Text = "";
                txtproincome.Text = "0";
                txtinstock.Text = "0";
                txttotal.Text = "0";
                txtbuy.Text = "0";
                txtsale.Text = "0";
                txtless.Text = "0";
                DataConn.conn.Close();

            }
            else
            {
                //  MessageBox.Show(" is not deleted from the system ");

            }

        }

        private void txtinstock_TextChanged(object sender, EventArgs e)
        {

          

        }

            

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtbillno.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtpropass.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txtproname.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            txtprogroup.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            txtprotype.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            txtproincome.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            txtinstock.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
            txttotal.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
            txtbuy.Text = dataGridView1.CurrentRow.Cells[9].Value.ToString();
            txtsale.Text = dataGridView1.CurrentRow.Cells[10].Value.ToString();
            txtdate.Text = dataGridView1.CurrentRow.Cells[11].Value.ToString();
            txtless.Text = dataGridView1.CurrentRow.Cells[12].Value.ToString();
            ImageGet1();
        }
    }
}
