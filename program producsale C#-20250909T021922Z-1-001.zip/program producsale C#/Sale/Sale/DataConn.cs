﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using Microsoft.VisualBasic;
namespace Sale
{
    class DataConn
    {
        public static string sqL;
        public static MySqlCommand cmd;
        public static MySqlDataReader dr;
        public static MySqlConnection conn = new MySqlConnection();

        public static void ConnDB()
        {
            conn = new MySqlConnection();
            conn.Close();
            try
            {

                conn.ConnectionString = "server=localhost;user id=root;Password=wy178900;Port=3306;database=dataprosale2021;charset=utf8; pooling=false";
                conn.Open();
                //Interaction.MsgBox("Connection Yes", MsgBoxStyle.Information, "Database Settings");
            }
            catch
            {
                Interaction.MsgBox("ບໍ່ສາມາດເຊື່ອມຕໍ່ຖານຂໍ້ມູນໄດ້", MsgBoxStyle.Information, "Database Settings");
            }
        }
        public static void DisconnMy()
        {
            conn.Close();
            conn.Dispose();

        }

    }
}
