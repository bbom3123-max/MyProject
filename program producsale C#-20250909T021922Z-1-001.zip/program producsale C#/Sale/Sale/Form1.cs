﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Microsoft.VisualBasic;
namespace Sale
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            AddNewStudent();
            LoadStdDetail();

        }

        private void AddNewStudent()
        {
            try
            {

                if (Cdstate.Text == "admin")
                {
                    MessageBox.Show("you cant't is a Admin");
                    return;
                    
                }

                DataConn.sqL = "SELECT * FROM tbusers WHERE username = '" + TxtName.Text + "'";
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.dr = DataConn.cmd.ExecuteReader();
                if (DataConn.dr.Read() == true)
                {
                    MessageBox.Show("ຂໍ້ມູນນີ້ມີແລ້ວກະລູນາປ່ຽນໃໝ່");
                    TxtName.Text = "";
                    TxtName.Focus();
                }
                else
                {

                    DataConn.sqL = "INSERT INTO tbusers(username, userpass, userstate) VALUES('" + TxtName.Text + "', '" + TxtPassword.Text + "','" + Cdstate.Text + "')";
                    DataConn.ConnDB();
                    DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                    DataConn.cmd.ExecuteNonQuery();
                    //Interaction.MsgBox("New category successfully added.", MsgBoxStyle.Information, "Add New User");
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                DataConn.cmd.Dispose();
                DataConn.conn.Close();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadStdDetail();
        }

        private void LoadStdDetail()
        {
            try
            {
                DataConn.sqL = "SELECT * FROM  tbusers";// WHERE Build_groupuse = '" + TxtGroupB.Text + "' AND Build_departuse = '" + TxtDepartB.Text + "' AND Build_sectionuse = '" + TxtSectionB.Text + "' And Build_UseNow=1";  
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.dr = DataConn.cmd.ExecuteReader();

                dataGridView1.Rows.Clear();
                {
                    while (DataConn.dr.Read() == true)
                    {
                        dataGridView1.Rows.Add((dataGridView1.RowCount+1),DataConn.dr[1], DataConn.dr[2], DataConn.dr[3]);
                    }
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message);
            }
            finally
            {
                DataConn.cmd.Dispose();
                DataConn.conn.Close();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            TxtName.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            TxtPassword.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            Cdstate.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UpdalandDoc();
            LoadStdDetail();
        }


        private void UpdalandDoc()
        {
            try
            {
                DataConn.sqL = "UPDATE tbusers SET  userpass = '" + TxtPassword.Text + "', userstate ='" + Cdstate.Text + "' WHERE username = '" + TxtName.Text + "'";
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.cmd.ExecuteNonQuery();
                Interaction.MsgBox("Category successfully updated.", MsgBoxStyle.Information, "Update Category");
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                DataConn.cmd.Dispose();
                DataConn.conn.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DeleteData();
            LoadStdDetail();
        }

        private void DeleteData()
        {
            if (MessageBox.Show("Are You sure you want to delete ", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                == DialogResult.Yes)
            {
                DataConn.sqL = "DELETE from tbusers WHERE username='" + TxtName.Text + "'"; //User_Name= '" + Txt_Name.Text + "', User_Pass = '" + Txt_Pass.Text + "' , User_State = '" + Cmb_State.Text + "' WHERE User_Name = '" + Txt_Name.Text + "'";
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.cmd.ExecuteNonQuery();
                Interaction.MsgBox("Category successfully Delete.", MsgBoxStyle.Information, "Delete Category");
                DataConn.conn.Close();
                
            }
            else
            {
                //  MessageBox.Show(" is not deleted from the system ");

            }

        }

        private void TxtName_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }



    }
}