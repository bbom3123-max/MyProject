﻿namespace Sale
{
    partial class Formproname
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbprogroup = new System.Windows.Forms.ComboBox();
            this.cmbprotype = new System.Windows.Forms.ComboBox();
            this.txtpropass = new System.Windows.Forms.TextBox();
            this.txtproname = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.propicture = new System.Windows.Forms.PictureBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.propicture)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(59, 54);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "ຊື່ໝວດສີນຄ້າ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(59, 100);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "ຊື່ປະເພດສີນຄ້າ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(59, 143);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 18);
            this.label3.TabIndex = 2;
            this.label3.Text = "ລະຫັດສີນຄ້າ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(59, 188);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 18);
            this.label4.TabIndex = 3;
            this.label4.Text = "ຊື່ສີນຄ້າ";
            // 
            // cmbprogroup
            // 
            this.cmbprogroup.FormattingEnabled = true;
            this.cmbprogroup.Location = new System.Drawing.Point(153, 54);
            this.cmbprogroup.Margin = new System.Windows.Forms.Padding(4);
            this.cmbprogroup.Name = "cmbprogroup";
            this.cmbprogroup.Size = new System.Drawing.Size(160, 26);
            this.cmbprogroup.TabIndex = 4;
            this.cmbprogroup.SelectedIndexChanged += new System.EventHandler(this.cmbprogroup_SelectedIndexChanged);
            // 
            // cmbprotype
            // 
            this.cmbprotype.FormattingEnabled = true;
            this.cmbprotype.Location = new System.Drawing.Point(153, 100);
            this.cmbprotype.Margin = new System.Windows.Forms.Padding(4);
            this.cmbprotype.Name = "cmbprotype";
            this.cmbprotype.Size = new System.Drawing.Size(160, 26);
            this.cmbprotype.TabIndex = 5;
            // 
            // txtpropass
            // 
            this.txtpropass.Location = new System.Drawing.Point(153, 143);
            this.txtpropass.Margin = new System.Windows.Forms.Padding(4);
            this.txtpropass.Name = "txtpropass";
            this.txtpropass.Size = new System.Drawing.Size(160, 27);
            this.txtpropass.TabIndex = 6;
            this.txtpropass.TextChanged += new System.EventHandler(this.txtpropass_TextChanged);
            // 
            // txtproname
            // 
            this.txtproname.Location = new System.Drawing.Point(153, 188);
            this.txtproname.Margin = new System.Windows.Forms.Padding(4);
            this.txtproname.Name = "txtproname";
            this.txtproname.Size = new System.Drawing.Size(160, 27);
            this.txtproname.TabIndex = 7;
            this.txtproname.TextChanged += new System.EventHandler(this.txtproname_TextChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4});
            this.dataGridView1.Location = new System.Drawing.Point(40, 330);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(453, 150);
            this.dataGridView1.TabIndex = 15;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "ຊື່ໝວດສີນຄ້າ";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "ຊື່ປະເພດສີນຄ້າ";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "ລະຫັດສີນຄ້າ";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.HeaderText = "ຊື່ສີນຄ້າ";
            this.Column4.Name = "Column4";
            // 
            // propicture
            // 
            this.propicture.Image = global::Sale.Properties.Resources.NoImage;
            this.propicture.Location = new System.Drawing.Point(410, 12);
            this.propicture.Name = "propicture";
            this.propicture.Size = new System.Drawing.Size(192, 221);
            this.propicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.propicture.TabIndex = 14;
            this.propicture.TabStop = false;
            this.propicture.Click += new System.EventHandler(this.propicture_Click);
            // 
            // button5
            // 
            this.button5.Image = global::Sale.Properties.Resources.choose;
            this.button5.Location = new System.Drawing.Point(466, 245);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(95, 63);
            this.button5.TabIndex = 12;
            this.button5.Text = "ເລືອກຮູບສີນຄ້າ";
            this.button5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Image = global::Sale.Properties.Resources.exit;
            this.button4.Location = new System.Drawing.Point(301, 239);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 75);
            this.button4.TabIndex = 11;
            this.button4.Text = "ອອກ";
            this.button4.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Image = global::Sale.Properties.Resources.delete;
            this.button3.Location = new System.Drawing.Point(220, 239);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 75);
            this.button3.TabIndex = 10;
            this.button3.Text = "ລຶບ";
            this.button3.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Image = global::Sale.Properties.Resources.edit;
            this.button2.Location = new System.Drawing.Point(139, 239);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 75);
            this.button2.TabIndex = 9;
            this.button2.Text = "ແກ້ໄຂ";
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Image = global::Sale.Properties.Resources.save;
            this.button1.Location = new System.Drawing.Point(60, 239);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(71, 75);
            this.button1.TabIndex = 8;
            this.button1.Text = "ບັນທຶກ";
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Formproname
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(715, 492);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.propicture);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtproname);
            this.Controls.Add(this.txtpropass);
            this.Controls.Add(this.cmbprotype);
            this.Controls.Add(this.cmbprogroup);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Phetsarath OT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Formproname";
            this.Text = "Formproname";
            this.Load += new System.EventHandler(this.Formproname_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.propicture)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbprogroup;
        private System.Windows.Forms.ComboBox cmbprotype;
        private System.Windows.Forms.TextBox txtpropass;
        private System.Windows.Forms.TextBox txtproname;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.PictureBox propicture;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
    }
}