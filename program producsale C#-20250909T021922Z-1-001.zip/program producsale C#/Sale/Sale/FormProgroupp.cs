﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Microsoft.VisualBasic;

namespace Sale
{
    public partial class FormProgroup : Form
    {
        public FormProgroup()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddNewStudent();
            LoadStdDetail();
        }

        private void AddNewStudent()
        {
            try
            {

                DataConn.sqL = "INSERT INTO tbprogroup (progrouppass, progroupname) VALUES('" + txtpassword.Text + "','" + txtprogroup.Text + "')";
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.cmd.ExecuteNonQuery();
                Interaction.MsgBox("New category successfully added.", MsgBoxStyle.Information, "Add New User");
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                DataConn.cmd.Dispose();
                DataConn.conn.Close();
            }
        }

        private void FormProgroup_Load(object sender, EventArgs e)
        {
            LoadStdDetail();
        }

        private void LoadStdDetail()
        {
            try
            {
                DataConn.sqL = "SELECT * FROM  tbprogroup";// WHERE Build_groupuse = '" + TxtGroupB.Text + "' AND Build_departuse = '" + TxtDepartB.Text + "' AND Build_sectionuse = '" + TxtSectionB.Text + "' And Build_UseNow=1";  
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.dr = DataConn.cmd.ExecuteReader();

                dataGridView1.Rows.Clear();
                {
                    while (DataConn.dr.Read() == true)
                    {
                        dataGridView1.Rows.Add(DataConn.dr[1], DataConn.dr[2]);
                    }
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message);
            }
            finally
            {
                DataConn.cmd.Dispose();
                DataConn.conn.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UpdaGroup();
            LoadStdDetail();
            
        }

        private void UpdaGroup()
        {
            try
            {
                DataConn.sqL = "UPDATE tbprogroup SET  progroupname = '" + txtprogroup.Text + "' WHERE progrouppass ='" + txtpassword.Text + "'";
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.cmd.ExecuteNonQuery();
                Interaction.MsgBox("Category successfully updated.", MsgBoxStyle.Information, "Update Category");
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                DataConn.cmd.Dispose();
                DataConn.conn.Close();
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            {
                txtpassword.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                txtprogroup.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
               
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DeleteData();
            LoadStdDetail();
        }

        private void DeleteData()
        {
            if (MessageBox.Show("Are You sure you want to delete ", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                == DialogResult.Yes)
            {
                DataConn.sqL = "DELETE from tbprogroup  WHERE progrouppass ='" + txtpassword.Text + "'"; //User_Name= '" + Txt_Name.Text + "', User_Pass = '" + Txt_Pass.Text + "' , User_State = '" + Cmb_State.Text + "' WHERE User_Name = '" + Txt_Name.Text + "'";
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.cmd.ExecuteNonQuery();
                Interaction.MsgBox("Category successfully Delete.", MsgBoxStyle.Information, "Delete Category");
                DataConn.conn.Close();
               
            }
            else
            {
                //  MessageBox.Show(" is not deleted from the system ");

            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
       }


    }
}
