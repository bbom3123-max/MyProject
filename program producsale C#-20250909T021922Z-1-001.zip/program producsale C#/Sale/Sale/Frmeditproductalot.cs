﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Microsoft.VisualBasic;

namespace Sale
{
    public partial class Frmeditproductalot : Form
    {
        public Frmeditproductalot()
        {
            InitializeComponent();
        }

        private void Frmeditproductalot_Load(object sender, EventArgs e)
        {
            LoadPrTail();
        }
        private void LoadPrTail()
        {
            try
            {
                DataConn.sqL = "SELECT * FROM   tbproductalot";// WHERE Build_groupuse = '" + TxtGroupB.Text + "' AND Build_departuse = '" + TxtDepartB.Text + "' AND Build_sectionuse = '" + TxtSectionB.Text + "' And Build_UseNow=1";  
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.dr = DataConn.cmd.ExecuteReader();

                dataGridView1.Rows.Clear();
                {
                    while (DataConn.dr.Read() == true)
                    {
                        dataGridView1.Rows.Add(DataConn.dr[2], DataConn.dr[3], DataConn.dr[10]);
                    }
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message);
            }
            finally
            {
                DataConn.cmd.Dispose();
                DataConn.conn.Close();
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtpropass.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtproname.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtprosale.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UpdatePrPeic();
            LoadPrTail();
        }
        private void UpdatePrPeic()
        {
            DataConn.sqL = "SELECT * FROM  tbproductalot where propass='" + txtpropass.Text + "'";
            DataConn.ConnDB();
            DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
            DataConn.dr = DataConn.cmd.ExecuteReader();
            if (DataConn.dr.Read() == true)
            {

                DataConn.sqL = "UPDATE tbproductalot SET prosale = '" + txtprosale.Text + "' where propass='" + txtpropass.Text + "'";
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.cmd.ExecuteNonQuery();

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }


    }
}
