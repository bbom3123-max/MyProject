﻿namespace Sale
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.ເມນຫກToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ຂມນຜໃຊToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ຂມນໝວດສນຄາToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ຂມນປະເພດສນຄາToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ຂມນລາຍການສນຄາToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ສນຄາToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ເພມສນຄາToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ອບເດດລາຄາສນຄາToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ຂາຍToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ຂາຍສນຄາToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ຂາຍຍກToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ຂາຍຍອຍToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ຂາຍToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ອອກຈາກລະບບToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip = new System.Windows.Forms.ToolStrip();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip.SuspendLayout();
            this.toolStrip.SuspendLayout();
            this.statusStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ເມນຫກToolStripMenuItem,
            this.ສນຄາToolStripMenuItem,
            this.ຂາຍສນຄາToolStripMenuItem,
            this.ອອກຈາກລະບບToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(797, 48);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // ເມນຫກToolStripMenuItem
            // 
            this.ເມນຫກToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ຂມນຜໃຊToolStripMenuItem,
            this.ຂມນໝວດສນຄາToolStripMenuItem,
            this.ຂມນປະເພດສນຄາToolStripMenuItem,
            this.ຂມນລາຍການສນຄາToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.ເມນຫກToolStripMenuItem.Font = new System.Drawing.Font("Phetsarath OT", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ເມນຫກToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.ເມນຫກToolStripMenuItem.Image = global::Sale.Properties.Resources.stroe;
            this.ເມນຫກToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ເມນຫກToolStripMenuItem.Name = "ເມນຫກToolStripMenuItem";
            this.ເມນຫກToolStripMenuItem.Size = new System.Drawing.Size(146, 44);
            this.ເມນຫກToolStripMenuItem.Text = "ເມນູຫຼັກ";
            // 
            // ຂມນຜໃຊToolStripMenuItem
            // 
            this.ຂມນຜໃຊToolStripMenuItem.Font = new System.Drawing.Font("Phetsarath OT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ຂມນຜໃຊToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.ຂມນຜໃຊToolStripMenuItem.Name = "ຂມນຜໃຊToolStripMenuItem";
            this.ຂມນຜໃຊToolStripMenuItem.Size = new System.Drawing.Size(242, 46);
            this.ຂມນຜໃຊToolStripMenuItem.Text = "ຂໍ້ມູນຜູ້ໃຊ້";
            this.ຂມນຜໃຊToolStripMenuItem.Click += new System.EventHandler(this.ຂມນຜໃຊToolStripMenuItem_Click);
            // 
            // ຂມນໝວດສນຄາToolStripMenuItem
            // 
            this.ຂມນໝວດສນຄາToolStripMenuItem.Font = new System.Drawing.Font("Phetsarath OT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ຂມນໝວດສນຄາToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.ຂມນໝວດສນຄາToolStripMenuItem.Name = "ຂມນໝວດສນຄາToolStripMenuItem";
            this.ຂມນໝວດສນຄາToolStripMenuItem.Size = new System.Drawing.Size(242, 46);
            this.ຂມນໝວດສນຄາToolStripMenuItem.Text = "ຂໍ້ມູນໝວດສີນຄ້າ";
            this.ຂມນໝວດສນຄາToolStripMenuItem.Click += new System.EventHandler(this.ຂມນໝວດສນຄາToolStripMenuItem_Click);
            // 
            // ຂມນປະເພດສນຄາToolStripMenuItem
            // 
            this.ຂມນປະເພດສນຄາToolStripMenuItem.Font = new System.Drawing.Font("Phetsarath OT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ຂມນປະເພດສນຄາToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.ຂມນປະເພດສນຄາToolStripMenuItem.Name = "ຂມນປະເພດສນຄາToolStripMenuItem";
            this.ຂມນປະເພດສນຄາToolStripMenuItem.Size = new System.Drawing.Size(242, 46);
            this.ຂມນປະເພດສນຄາToolStripMenuItem.Text = "ຂໍ້ມູນປະເພດສີນຄ້າ";
            this.ຂມນປະເພດສນຄາToolStripMenuItem.Click += new System.EventHandler(this.ຂມນປະເພດສນຄາToolStripMenuItem_Click);
            // 
            // ຂມນລາຍການສນຄາToolStripMenuItem
            // 
            this.ຂມນລາຍການສນຄາToolStripMenuItem.Font = new System.Drawing.Font("Phetsarath OT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ຂມນລາຍການສນຄາToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.ຂມນລາຍການສນຄາToolStripMenuItem.Name = "ຂມນລາຍການສນຄາToolStripMenuItem";
            this.ຂມນລາຍການສນຄາToolStripMenuItem.Size = new System.Drawing.Size(242, 46);
            this.ຂມນລາຍການສນຄາToolStripMenuItem.Text = "ຂໍ້ມູນລາຍການສີນຄ້າ";
            this.ຂມນລາຍການສນຄາToolStripMenuItem.Click += new System.EventHandler(this.ຂມນລາຍການສນຄາToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.exitToolStripMenuItem.Image = global::Sale.Properties.Resources.exit;
            this.exitToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.exitToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(242, 46);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // ສນຄາToolStripMenuItem
            // 
            this.ສນຄາToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ເພມສນຄາToolStripMenuItem,
            this.ອບເດດລາຄາສນຄາToolStripMenuItem,
            this.ຂາຍToolStripMenuItem});
            this.ສນຄາToolStripMenuItem.Font = new System.Drawing.Font("Phetsarath OT", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ສນຄາToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.ສນຄາToolStripMenuItem.Image = global::Sale.Properties.Resources.picture;
            this.ສນຄາToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ສນຄາToolStripMenuItem.Name = "ສນຄາToolStripMenuItem";
            this.ສນຄາToolStripMenuItem.Size = new System.Drawing.Size(216, 44);
            this.ສນຄາToolStripMenuItem.Text = "ຂາຍສີນຄ້າຍ່ອຍ";
            this.ສນຄາToolStripMenuItem.Click += new System.EventHandler(this.ສນຄາToolStripMenuItem_Click);
            // 
            // ເພມສນຄາToolStripMenuItem
            // 
            this.ເພມສນຄາToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.ເພມສນຄາToolStripMenuItem.Image = global::Sale.Properties.Resources.product;
            this.ເພມສນຄາToolStripMenuItem.Name = "ເພມສນຄາToolStripMenuItem";
            this.ເພມສນຄາToolStripMenuItem.Size = new System.Drawing.Size(287, 44);
            this.ເພມສນຄາToolStripMenuItem.Text = "ເພີ່ມສີນຄ້າ";
            this.ເພມສນຄາToolStripMenuItem.Click += new System.EventHandler(this.ເພມສນຄາToolStripMenuItem_Click);
            // 
            // ອບເດດລາຄາສນຄາToolStripMenuItem
            // 
            this.ອບເດດລາຄາສນຄາToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.ອບເດດລາຄາສນຄາToolStripMenuItem.Name = "ອບເດດລາຄາສນຄາToolStripMenuItem";
            this.ອບເດດລາຄາສນຄາToolStripMenuItem.Size = new System.Drawing.Size(287, 44);
            this.ອບເດດລາຄາສນຄາToolStripMenuItem.Text = "ອັບເດດລາຄາສີນຄ້າ";
            this.ອບເດດລາຄາສນຄາToolStripMenuItem.Click += new System.EventHandler(this.ອບເດດລາຄາສນຄາToolStripMenuItem_Click);
            // 
            // ຂາຍToolStripMenuItem
            // 
            this.ຂາຍToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.ຂາຍToolStripMenuItem.Name = "ຂາຍToolStripMenuItem";
            this.ຂາຍToolStripMenuItem.Size = new System.Drawing.Size(287, 44);
            this.ຂາຍToolStripMenuItem.Text = "ຂາຍ";
            this.ຂາຍToolStripMenuItem.Click += new System.EventHandler(this.ຂາຍToolStripMenuItem_Click);
            // 
            // ຂາຍສນຄາToolStripMenuItem
            // 
            this.ຂາຍສນຄາToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ຂາຍຍກToolStripMenuItem,
            this.ຂາຍຍອຍToolStripMenuItem,
            this.ຂາຍToolStripMenuItem1});
            this.ຂາຍສນຄາToolStripMenuItem.Font = new System.Drawing.Font("Phetsarath OT", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ຂາຍສນຄາToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.ຂາຍສນຄາToolStripMenuItem.Image = global::Sale.Properties.Resources.picture1;
            this.ຂາຍສນຄາToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ຂາຍສນຄາToolStripMenuItem.Name = "ຂາຍສນຄາToolStripMenuItem";
            this.ຂາຍສນຄາToolStripMenuItem.Size = new System.Drawing.Size(202, 44);
            this.ຂາຍສນຄາToolStripMenuItem.Text = "ຂາຍສີນຄ້າຍົກ";
            this.ຂາຍສນຄາToolStripMenuItem.Click += new System.EventHandler(this.ຂາຍສນຄາToolStripMenuItem_Click);
            // 
            // ຂາຍຍກToolStripMenuItem
            // 
            this.ຂາຍຍກToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.ຂາຍຍກToolStripMenuItem.Image = global::Sale.Properties.Resources.product;
            this.ຂາຍຍກToolStripMenuItem.Name = "ຂາຍຍກToolStripMenuItem";
            this.ຂາຍຍກToolStripMenuItem.Size = new System.Drawing.Size(287, 44);
            this.ຂາຍຍກToolStripMenuItem.Text = "ເພີ່ມສີນຄ້າ";
            this.ຂາຍຍກToolStripMenuItem.Click += new System.EventHandler(this.ຂາຍຍກToolStripMenuItem_Click);
            // 
            // ຂາຍຍອຍToolStripMenuItem
            // 
            this.ຂາຍຍອຍToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.ຂາຍຍອຍToolStripMenuItem.Name = "ຂາຍຍອຍToolStripMenuItem";
            this.ຂາຍຍອຍToolStripMenuItem.Size = new System.Drawing.Size(287, 44);
            this.ຂາຍຍອຍToolStripMenuItem.Text = "ອັບເດດລາຄາສີນຄ້າ";
            this.ຂາຍຍອຍToolStripMenuItem.Click += new System.EventHandler(this.ຂາຍຍອຍToolStripMenuItem_Click);
            // 
            // ຂາຍToolStripMenuItem1
            // 
            this.ຂາຍToolStripMenuItem1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.ຂາຍToolStripMenuItem1.Name = "ຂາຍToolStripMenuItem1";
            this.ຂາຍToolStripMenuItem1.Size = new System.Drawing.Size(287, 44);
            this.ຂາຍToolStripMenuItem1.Text = "ຂາຍ";
            this.ຂາຍToolStripMenuItem1.Click += new System.EventHandler(this.ຂາຍToolStripMenuItem1_Click);
            // 
            // ອອກຈາກລະບບToolStripMenuItem
            // 
            this.ອອກຈາກລະບບToolStripMenuItem.Font = new System.Drawing.Font("Phetsarath OT", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ອອກຈາກລະບບToolStripMenuItem.ForeColor = System.Drawing.SystemColors.Highlight;
            this.ອອກຈາກລະບບToolStripMenuItem.Name = "ອອກຈາກລະບບToolStripMenuItem";
            this.ອອກຈາກລະບບToolStripMenuItem.Size = new System.Drawing.Size(178, 44);
            this.ອອກຈາກລະບບToolStripMenuItem.Text = "ອອກຈາກລະບົບ";
            this.ອອກຈາກລະບບToolStripMenuItem.Click += new System.EventHandler(this.ອອກຈາກລະບບToolStripMenuItem_Click);
            // 
            // toolStrip
            // 
            this.toolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator1,
            this.toolStripSeparator2});
            this.toolStrip.Location = new System.Drawing.Point(0, 48);
            this.toolStrip.Name = "toolStrip";
            this.toolStrip.Size = new System.Drawing.Size(797, 25);
            this.toolStrip.TabIndex = 1;
            this.toolStrip.Text = "ToolStrip";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 431);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(797, 22);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "StatusStrip";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(39, 17);
            this.toolStripStatusLabel.Text = "Status";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Sale.Properties.Resources.photo_goroda_kanadi_10;
            this.pictureBox1.Location = new System.Drawing.Point(0, 76);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(797, 352);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(797, 453);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.toolStrip);
            this.Controls.Add(this.menuStrip);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "FrmMain";
            this.Text = "FrmMain";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.toolStrip.ResumeLayout(false);
            this.toolStrip.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion


        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStrip toolStrip;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ToolStripMenuItem ເມນຫກToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ຂມນຜໃຊToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ຂມນໝວດສນຄາToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ຂມນປະເພດສນຄາToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ຂມນລາຍການສນຄາToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ສນຄາToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ຂາຍສນຄາToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ອອກຈາກລະບບToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ຂາຍຍກToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ຂາຍຍອຍToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ເພມສນຄາToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ອບເດດລາຄາສນຄາToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ຂາຍToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ຂາຍToolStripMenuItem1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}



