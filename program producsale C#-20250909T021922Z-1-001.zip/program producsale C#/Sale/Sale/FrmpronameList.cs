﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Microsoft.VisualBasic;

namespace Sale
{
    public partial class FrmpronameList : Form
    {
        public FrmpronameList()
        {
            InitializeComponent();
        }

        private void FrmpronameList_Load(object sender, EventArgs e)
        {
            LoadproList();
        }

        private void LoadproList()
        {
            try
            {
                DataConn.sqL = "SELECT * FROM  tbproname";// WHERE Build_groupuse = '" + TxtGroupB.Text + "' AND Build_departuse = '" + TxtDepartB.Text + "' AND Build_sectionuse = '" + TxtSectionB.Text + "' And Build_UseNow=1";  
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.dr = DataConn.cmd.ExecuteReader();

                dataGridView1.Rows.Clear();
                {
                    while (DataConn.dr.Read() == true)
                    {
                        dataGridView1.Rows.Add(DataConn.dr[1], DataConn.dr[2], DataConn.dr[3], DataConn.dr[4]);
                    }
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message);
            }
            finally
            {
                DataConn.cmd.Dispose();
                DataConn.conn.Close();
            }
        }

    }
}
