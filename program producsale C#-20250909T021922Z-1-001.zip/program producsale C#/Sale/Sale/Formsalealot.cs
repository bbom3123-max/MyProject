﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Microsoft.VisualBasic;
using System.IO;

namespace Sale
{
    public partial class Formsalealot : Form
    {
        public Formsalealot()
        {
            InitializeComponent();
        }

        private void txtpropass_TextChanged(object sender, EventArgs e)
        {
           // SearchImage();
           // Loadpro();
           // Loadproduct();
        }
        private void SearchImage()
        {
            //Dataconn.sqL = "SELECT * FROM tb_Beverage WHERE Beverage_Id = '" + (dataGridView1.CurrentRow.Cells[0].Value.ToString()) + "'";
            DataConn.sqL = "SELECT * FROM  tbproname WHERE propass = '" + (txtpropass.Text) + "'";
            DataConn.ConnDB();
            DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
            DataConn.dr = DataConn.cmd.ExecuteReader();
            while (DataConn.dr.Read())
            {
                byte[] imgg = (byte[])(DataConn.dr["proimage"]);
                if (imgg == null)
                {
                    propicture.Image = null;
                }
                else
                {


                    //TxtProname.Text = (DataConn.dr.GetString("proname"));
                    //TxtProtype.Text = (DataConn.dr.GetString("typename"));
                    //TxtProgroup.Text = (DataConn.dr.GetString("groupname"));

                    MemoryStream mstream = new MemoryStream(imgg);
                    propicture.Image = System.Drawing.Image.FromStream(mstream);
                }

            }
            DataConn.conn.Close();

        }
        private void Loadpro()
        {

            {
                DataConn.sqL = "SELECT * FROM  tbproductalot where propass='" + (txtpropass.Text) + "'";
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.dr = DataConn.cmd.ExecuteReader();
                if (DataConn.dr.Read() == true)
                {
                    //Txtid.Text = (DataConn.dr.GetString("proid"));
                    txtproname.Text = (DataConn.dr.GetString("proname"));
                    txtproprice.Text = (DataConn.dr.GetString("prosale"));
                    double x, y, z;
                    x = Convert.ToDouble(txtproprice.Text);
                    y = Convert.ToDouble(txtpronumber.Text);
                    z = x * y;
                    txtprototal.Text = z.ToString();

                }

            }
        }

        private void Formsalealot_Load(object sender, EventArgs e)
        {
            Loadproduct();
        }
        private void Loadproduct()
        {
            try
            {
                DataConn.sqL = "SELECT * FROM  tbprosalealot";// WHERE Build_groupuse = '" + TxtGroupB.Text + "' AND Build_departuse = '" + TxtDepartB.Text + "' AND Build_sectionuse = '" + TxtSectionB.Text + "' And Build_UseNow=1";  
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.dr = DataConn.cmd.ExecuteReader();

                dataGridView1.Rows.Clear();
                {
                    while (DataConn.dr.Read() == true)
                    {
                        dataGridView1.Rows.Add((dataGridView1.RowCount + 1), DataConn.dr[1], DataConn.dr[2], DataConn.dr[3], DataConn.dr[4], DataConn.dr[5], DataConn.dr[6], DataConn.dr[7], DataConn.dr[8]);
                    }
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message);
            }
            finally
            {
                DataConn.cmd.Dispose();
                DataConn.conn.Close();
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtprobill.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtpropass.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txtproname.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            txtproprice.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
           // txtpronumber.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            txtprototal.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            prodate.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
            allprice.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AddNewproduct();
            Loadproduct();
        }
        private void AddNewproduct()
        {
            try
            {
                DataConn.sqL = "SELECT * FROM  tbproductalot where propass='" + txtpropass.Text + "'";
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.dr = DataConn.cmd.ExecuteReader();
                if (DataConn.dr.Read() == false)
                {
                    Interaction.MsgBox("ບໍ່ມີສິນຄ້ານີ້ໃນລະບົບ.", MsgBoxStyle.Information, "Add.User");
                    return;
                }

                DataConn.sqL = "SELECT * FROM tbprosalealot where probill='" + txtprobill.Text + "' and propass='" + txtpropass.Text + "'";
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.dr = DataConn.cmd.ExecuteReader();
                if (DataConn.dr.Read() == true)
                {
                    Double x, y, z;
                    z = Convert.ToInt32(txtproprice.Text);
                    y = Convert.ToInt32(txtpronumber.Text);
                    x = (DataConn.dr.GetInt32("pronumber"));
                    DataConn.sqL = "UPDATE tbprosalealot SET  pronumber = '" + (y + x) + "', total = '" + (y + x) * z + "' where probill='" + txtprobill.Text + "' and propass='" + txtpropass.Text + "'";
                    DataConn.ConnDB();
                    DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                    DataConn.cmd.ExecuteNonQuery();

                }

                else
                    DataConn.sqL = "INSERT INTO tbprosalealot(probill,propass,proname,propice,pronumber,total,prodate,allprice) VALUES('" + txtprobill.Text + "', '" + txtpropass.Text + "','" + txtproname.Text + "', '" + txtproprice.Text + "', '" + txtpronumber.Text + "', '" + txtprototal.Text + "', '" + prodate.Text + "', '" + allprice.Text + "')";
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.cmd.ExecuteNonQuery();
                //Interaction.MsgBox("New category successfully added.", MsgBoxStyle.Information, "Add New User");
            }

            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                DataConn.cmd.Dispose();
                DataConn.conn.Close();
            }
        }


        private void txtpropass_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                SearchImage();
                Loadpro();
                AddNewproduct();
                Loadproduct();
                Calculatesumtotal();
                Stokdown();
            }

        }
        private void Calculatesumtotal()
        {

            int sum = 0;

            for (int i = 0; i < dataGridView1.Rows.Count; ++i)
            {

                sum += Convert.ToInt32(dataGridView1.Rows[i].Cells[6].Value);

            }

            allprice.Text = sum.ToString();

        }
        private void Stokdown()
        {
            DataConn.sqL = "SELECT * FROM  tbproductalot where propass='" + txtpropass.Text + "'";
            DataConn.ConnDB();
            DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
            DataConn.dr = DataConn.cmd.ExecuteReader();
            if (DataConn.dr.Read() == true)
            {
                Double x, y;
                //z = Convert.ToInt32(TxtPrice.Text);
                x = Convert.ToInt32(txtpronumber.Text);
                y = (DataConn.dr.GetInt32("prototal"));
                DataConn.sqL = "UPDATE tbproductalot SET prototal = '" + (y - x) + "' where propass='" + txtpropass.Text + "'";
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.cmd.ExecuteNonQuery();

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
           SendProductc();
            Stokup();
            Loadproduct();
        }
        private void SendProductc()
        {
            DataConn.sqL = "SELECT * FROM  tbprosalealot where probill='" + dataGridView1.CurrentRow.Cells[1].Value.ToString() + "' And propass='" + dataGridView1.CurrentRow.Cells[2].Value.ToString() + "'";
            DataConn.ConnDB();
            DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
            DataConn.dr = DataConn.cmd.ExecuteReader();
            if (DataConn.dr.Read() == true)
            {
                Double x, y, z;
                z = Convert.ToInt32(txtprototal.Text);
                x = Convert.ToInt32(txtpronumber.Text);
                y = (DataConn.dr.GetInt32("pronumber"));
                DataConn.sqL = "UPDATE  tbprosalealot SET pronumber = '" + (y - x) + "',total = '" + (y - x) * z + "' where probill='" + dataGridView1.CurrentRow.Cells[1].Value.ToString() + "' And propass='" + dataGridView1.CurrentRow.Cells[2].Value.ToString() + "'";
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.cmd.ExecuteNonQuery();

            }
        }
        private void Stokup()
        {
            DataConn.sqL = "SELECT * FROM  tbproductalot where propass='" + txtpropass.Text + "'";
            DataConn.ConnDB();
            DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
            DataConn.dr = DataConn.cmd.ExecuteReader();
            if (DataConn.dr.Read() == true)
            {
                Double x, y;
                //z = Convert.ToInt32(TxtPrice.Text);
                x = Convert.ToInt32(txtpronumber.Text);
                y = (DataConn.dr.GetInt32("prototal"));
                DataConn.sqL = "UPDATE tbproductalot SET prototal = '" + (y + x) + "' where propass='" + txtpropass.Text + "'";
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.cmd.ExecuteNonQuery();

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
