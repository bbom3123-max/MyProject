﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Microsoft.VisualBasic;

namespace Sale
{
    public partial class FormProtypee : Form
    {
        public FormProtypee()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddNewStudent();
            LoadStdDetail();
            
        }

        private void AddNewStudent()
        {
            try
            {

                DataConn.sqL = "INSERT INTO tbprotype(proname, propassword, protype) VALUES('" + cmbproname.Text + "', '" + txtpropassword.Text + "','" + txtprotype.Text + "')";
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.cmd.ExecuteNonQuery();
                Interaction.MsgBox("New category successfully added.", MsgBoxStyle.Information, "Add New User");
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                DataConn.cmd.Dispose();
                DataConn.conn.Close();
            }
        }

        private void FormProGroup_Load(object sender, EventArgs e)
        {
            LoadStdDetail();
            LoadGroupName();
        }

        private void LoadStdDetail()
        {
            try
            {
                DataConn.sqL = "SELECT * FROM  tbprotype";// WHERE Build_groupuse = '" + TxtGroupB.Text + "' AND Build_departuse = '" + TxtDepartB.Text + "' AND Build_sectionuse = '" + TxtSectionB.Text + "' And Build_UseNow=1";  
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.dr = DataConn.cmd.ExecuteReader();

                dataGridView1.Rows.Clear();
                {
                    while (DataConn.dr.Read() == true)
                    {
                        dataGridView1.Rows.Add(DataConn.dr[1], DataConn.dr[2],DataConn.dr[3]);
                    }
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message);
            }
            finally
            {
                DataConn.cmd.Dispose();
                DataConn.conn.Close();
            }
        }
        private void LoadGroupName()
        {

            {
                DataConn.sqL = "SELECT * FROM  tbprogroup ";
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.dr = DataConn.cmd.ExecuteReader();
                while (DataConn.dr.Read() == true)
                {
                    cmbproname.Items.Add(DataConn.dr[2]);
                }

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UpdalandDoc();
            LoadStdDetail();
        }


        private void UpdalandDoc()
        {
            try
            {
                DataConn.sqL = "UPDATE tbprotype SET  propassword = '" + txtpropassword.Text + "', protype ='" + txtprotype.Text + "' WHERE proname = '" + cmbproname.Text + "'";
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.cmd.ExecuteNonQuery();
                Interaction.MsgBox("Category successfully updated.", MsgBoxStyle.Information, "Update Category");
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                DataConn.cmd.Dispose();
                DataConn.conn.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DeleteData();
            LoadStdDetail();
        }

        private void DeleteData()
        {
            if (MessageBox.Show("Are You sure you want to delete ", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                == DialogResult.Yes)
            {
                DataConn.sqL = "DELETE from tbprotype WHERE proname='" + cmbproname.Text + "'"; //User_Name= '" + Txt_Name.Text + "', User_Pass = '" + Txt_Pass.Text + "' , User_State = '" + Cmb_State.Text + "' WHERE User_Name = '" + Txt_Name.Text + "'";
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.cmd.ExecuteNonQuery();
                Interaction.MsgBox("Category successfully Delete.", MsgBoxStyle.Information, "Delete Category");
                DataConn.conn.Close();
                
            }
            else
            {
                //  MessageBox.Show(" is not deleted from the system ");

            }

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            cmbproname.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtpropassword.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
           txtprotype.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cmbproname_SelectedIndexChanged(object sender, EventArgs e)
        {

        }


    }
}
