﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Microsoft.VisualBasic;
using System.IO;

namespace Sale
{
    public partial class Formproname : Form
    {
        public Formproname()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddNewproname();
            Loadproname();
        }
             
        private void AddNewproname()
        {
            System.IO.MemoryStream mstream = new System.IO.MemoryStream();
            propicture.Image.Save(mstream, System.Drawing.Imaging.ImageFormat.Jpeg);
            byte[] arrImage = mstream.GetBuffer();
            //FileSize = mstream.Length;
            mstream.Close();
            try
            {

                    DataConn.sqL = "INSERT INTO tbproname(progroup, protype, propass, proname, proimage) VALUES('" + cmbprogroup.Text + "', '" + cmbprotype.Text + "','" + txtpropass.Text + "','" + txtproname.Text + "', @proimage)";
                    DataConn.ConnDB();
                    DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                    DataConn.cmd.Parameters.Add(new MySqlParameter("@proimage", arrImage));
                    DataConn.cmd.ExecuteNonQuery();
                    Interaction.MsgBox("New category successfully added.", MsgBoxStyle.Information, "Add New User");
                    txtpropass.Text = "";
                    txtproname.Text = "";
                    cmbprogroup.Text = "";
                    cmbprotype.Text = "";
                  
                }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                DataConn.cmd.Dispose();
                DataConn.conn.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Updateproname();
            Loadproname();
        }
        private void Updateproname()
        {

            System.IO.MemoryStream mstream = new System.IO.MemoryStream();
            propicture.Image.Save(mstream, System.Drawing.Imaging.ImageFormat.Jpeg);
            byte[] arrImage = mstream.GetBuffer();
            //FileSize = mstream.Length;
            mstream.Close();
            try
            {
                DataConn.sqL = "UPDATE tbproname SET  proname = '" + txtproname.Text + "' ,proimage=@proimage WHERE  propass ='" + txtpropass.Text + "'";
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.cmd.Parameters.Add(new MySqlParameter("@proimage", arrImage));
                DataConn.cmd.ExecuteNonQuery();
                Interaction.MsgBox("Category successfully updated.", MsgBoxStyle.Information, "Update Category");
                txtpropass.Text = "";
                txtproname.Text = "";
                cmbprogroup.Text = "";
                cmbprotype.Text = "";
               
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.ToString());
            }
            finally
            {
                DataConn.cmd.Dispose();
                DataConn.conn.Close();
            }
        }

      

        private void Formproname_Load(object sender, EventArgs e)
        {
            Loadproname();
            LoadGroupName();
            propicture.Image = Image.FromFile(@"..\..\Resources\NoImage.jpeg");
            //propicture.Image = Image.FromFile(@"..\Sale\Resources\NoImage.jpeg");
        }

        private void LoadGroupName()
        {

            {
                DataConn.sqL = "SELECT * FROM  tbprogroup ";
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.dr = DataConn.cmd.ExecuteReader();
                while (DataConn.dr.Read() == true)
                {
                    cmbprogroup.Items.Add(DataConn.dr[2]);
                }

            }
        }

        private void Loadproname()
        {
            try
            {
                DataConn.sqL = "SELECT * FROM  tbproname";// WHERE Build_groupuse = '" + TxtGroupB.Text + "' AND Build_departuse = '" + TxtDepartB.Text + "' AND Build_sectionuse = '" + TxtSectionB.Text + "' And Build_UseNow=1";  
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.dr = DataConn.cmd.ExecuteReader();

                dataGridView1.Rows.Clear();
                {
                    while (DataConn.dr.Read() == true)
                    {
                        dataGridView1.Rows.Add(DataConn.dr[1], DataConn.dr[2], DataConn.dr[3], DataConn.dr[4]);
                    }
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message);
            }
            finally
            {
                DataConn.cmd.Dispose();
                DataConn.conn.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Deleteproname();
            Loadproname();
        }

        private void Deleteproname()
        {
            if (MessageBox.Show("Are You sure you want to delete ", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                == DialogResult.Yes)
            {
                DataConn.sqL = "DELETE from tbproname  WHERE propass ='" + txtpropass.Text + "' and proname='" + txtproname.Text +"'"; //User_Name= '" + Txt_Name.Text + "', User_Pass = '" + Txt_Pass.Text + "' , User_State = '" + Cmb_State.Text + "' WHERE User_Name = '" + Txt_Name.Text + "'";
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.cmd.ExecuteNonQuery();
                Interaction.MsgBox("Category successfully Delete.", MsgBoxStyle.Information, "Delete Category");
                txtpropass.Text = "";
                txtproname.Text = "";
                cmbprogroup.Text = "";
                cmbprotype.Text = "";
              
                DataConn.conn.Close();

            }
            else
            {
                //  MessageBox.Show(" is not deleted from the system ");

            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void cmbprogroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadUser();
        }
        private void LoadUser()
        {

            {
                DataConn.sqL = "SELECT * FROM tbprotype where proname='" + cmbprogroup.Text + "'";
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.dr = DataConn.cmd.ExecuteReader();
                cmbprotype.Items.Clear();
                while (DataConn.dr.Read() == true)
                {
                 cmbprotype.Items.Add(DataConn.dr[3]);
                }

            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            {
                cmbprogroup.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                cmbprotype.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                txtpropass.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                txtproname.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                ImageGet();
            }
        }
        private void ImageGet()
        {
            //Dataconn.sqL = "SELECT * FROM tb_Beverage WHERE Beverage_Id = '" + (dataGridView1.CurrentRow.Cells[0].Value.ToString()) + "'";
            DataConn.sqL = "SELECT * FROM tbproname WHERE propass = '" + (dataGridView1.CurrentRow.Cells[2].Value.ToString()) + "'";
            DataConn.ConnDB();
            DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
            DataConn.dr = DataConn.cmd.ExecuteReader();
            while (DataConn.dr.Read())
            {
                byte[] imgg = (byte[])(DataConn.dr["proimage"]);
                if (imgg == null)
                {
                    propicture.Image = null;
                }
                else
                {
                    MemoryStream mstream = new MemoryStream(imgg);
                    propicture.Image = System.Drawing.Image.FromStream(mstream);
                }
            }
            DataConn.conn.Close();

        }
        private void button5_Click(object sender, EventArgs e)
        {
             try
            {
                OpenFileDialog openFileDialog1 = new OpenFileDialog();
                openFileDialog1.Filter = "Image files | *.jpg";
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    propicture.Text = openFileDialog1.FileName;
                    propicture.Image = Image.FromFile(openFileDialog1.FileName);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtpropass_TextChanged(object sender, EventArgs e)
        {
            SearchImage();
        }

        private void SearchImage()
        {
            //Dataconn.sqL = "SELECT * FROM tb_Beverage WHERE Beverage_Id = '" + (dataGridView1.CurrentRow.Cells[0].Value.ToString()) + "'";
            DataConn.sqL = "SELECT * FROM tbproname WHERE propass = '" + txtpropass.Text + "'";
            DataConn.ConnDB();
            DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
            DataConn.dr = DataConn.cmd.ExecuteReader();
            while (DataConn.dr.Read())
            {
                byte[] imgg = (byte[])(DataConn.dr["proimage"]);
                if (imgg == null)
                {
                    propicture.Image = null;
                }
                else
                {
                    MemoryStream mstream = new MemoryStream(imgg);
                    propicture.Image = System.Drawing.Image.FromStream(mstream);
                    txtproname.Text = (DataConn.dr.GetString("proname"));
                }
            }
            DataConn.conn.Close();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtproname_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void propicture_Click(object sender, EventArgs e)
        {

        }

      
        }
        }

      

       
