﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Microsoft.VisualBasic;

namespace Sale
{
    public partial class Frmlogin : Form
    {
        public Frmlogin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Login();
        }

        private void Login()
        {
            //try
            {
                DataConn.sqL = "SELECT * FROM tbusers WHERE username = '" + cmbname.Text + "' AND userpass = '"  + txtpassword.Text + "'";
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.dr = DataConn.cmd.ExecuteReader();
                if (DataConn.dr.Read() == true)
                {
                    FrmMain m = new FrmMain();
                    m.Show();
                    this.Hide();
                }

                else
                {
                    Interaction.MsgBox("ລະ​ຫັດ​ບໍ່​ຖຶກ​ຕ້ອງ", MsgBoxStyle.Exclamation, "Login");
                }

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Frmlogin_Load(object sender, EventArgs e)
        {
            LoadUser();
        }

        private void LoadUser()
        {

            {
                DataConn.sqL = "SELECT * FROM tbusers ";
                DataConn.ConnDB();
                DataConn.cmd = new MySqlCommand(DataConn.sqL, DataConn.conn);
                DataConn.dr = DataConn.cmd.ExecuteReader();
                while (DataConn.dr.Read() == true)
                {
                    cmbname.Items.Add(DataConn.dr[1]);
                }

            }
        }

        private void cmbname_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

    }
}
